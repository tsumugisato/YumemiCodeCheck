//
//  ViewController.swift
//  Tech1
//
//  Created by 高橋直輝 on 11/12/21.
//

import UIKit
import NCMB


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tableView : UITableView!
    @IBOutlet var appleAmountLabel: UILabel!
    @IBOutlet var pearAmountLabel: UILabel!
    @IBOutlet var amountLabel: UILabel!
    
    
    var posts = [NCMBObject]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 105
        
        loadDate()
        
        
        
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        
        //タグでパーツを指定
        let amountLabel = cell.viewWithTag(1) as! UILabel
        let appleLabel = cell.viewWithTag(2) as! UILabel
        let pearLabel = cell.viewWithTag(3) as! UILabel
        
        
        let applePrice = posts[indexPath.row].object(forKey: "apple") as! Int
        let pearPrice = posts[indexPath.row].object(forKey: "pear") as! Int
        let amountPrice = applePrice + pearPrice
        
        amountLabel.text = "今回の買い物の合計金額は\(amountPrice)円"
        appleLabel.text = "りんごの合計金額は\(applePrice)円"
        pearLabel.text = "洋梨の合計金額は\(pearPrice)円"
        
        
        return cell
    }
    
    func loadDate(){
        
        let query = NCMBQuery(className: "Shopping")
        
        //りんごと洋梨、全体の合計金額を格納する変数を用意
        var appleAmount = 0
        var pearAmount = 0
        var amount = 0
        
        query?.findObjectsInBackground({ result, error in
            if error != nil{
                print(error?.localizedDescription)
            }else{
                //NCMBObject型の配列として posts に代入
                self.posts = result as! [NCMBObject]
                print(self.posts.count)
                for i in result as! [NCMBObject] {
                    //りんごと洋梨の合計金額を加算していく
                    appleAmount += i.object(forKey: "apple") as! Int
                    pearAmount += i.object(forKey: "pear") as! Int
                    
                    
                    
                }
                //合計金額を格納する変数amountにりんご(appleAmount)の合計金額と洋梨(pearAmount)の合計金額を足して代入
                amount = appleAmount + pearAmount
                //各labelに出力
                self.amountLabel.text = "今回の買い物の合計金額は\(amount)円"
                self.pearAmountLabel.text = "洋梨の合計金額は\(appleAmount)円"
                self.appleAmountLabel.text = "りんごの合計金額は\(pearAmount)円"
    
                //tableViewの情報を更新してあげて表示
                self.tableView.reloadData()
            }
        })
    }
    
    


}

