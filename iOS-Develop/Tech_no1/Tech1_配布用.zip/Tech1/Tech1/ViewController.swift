//
//  ViewController.swift
//  Tech1
//
//  Created by 高橋直輝 on 11/12/21.
//

import UIKit
import NCMB


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tableView : UITableView!
    
    var posts = [NCMBObject]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        let amountLabel = cell.viewWithTag(1) as! UILabel
        let appleLabel = cell.viewWithTag(2) as! UILabel
        let pearLabel = cell.viewWithTag(3) as! UILabel
        
        amountLabel.text = "eeeeeeeeeee"
        appleLabel.text = "222222222222222"
        pearLabel.text = "539857923874"
        
        
        return cell
    }
    
    func loadDate(){
        let query = NCMBQuery(className: "Shopping")
    }
    
    


}

